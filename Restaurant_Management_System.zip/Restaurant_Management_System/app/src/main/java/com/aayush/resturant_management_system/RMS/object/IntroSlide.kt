package com.aayush.resturant_management_system.RMS.`object`

data class IntroSlide (
    val title: String,
    val description: String,
    val icon: Int
)