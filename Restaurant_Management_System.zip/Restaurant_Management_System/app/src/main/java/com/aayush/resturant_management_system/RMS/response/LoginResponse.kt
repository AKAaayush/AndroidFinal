package com.aayush.resturant_management_system.RMS.response

data class LoginResponse (
    val success:Boolean?=null,
    val token:String?=null
)